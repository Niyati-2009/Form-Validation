const apiKey="9a301fcb9275c82051064f47483b78b0";
async function getFetchData(endpoint,city){
    const apiURL=`https://api.openweathermap.org/data/2.5/${endpoint}?q=${city}&appid=${apiKey}&units=metric`
    const response= await fetch(apiURL)
    return response.json();
}
async function updateInfo(city){
const weather= await getFetchData('weather',city)
console.log(weather)
const display = document.getElementById("weatherDisplay");

      if (weather.cod !== 200){
        display.innerHTML = `<p>Error: ${weather.message}</p>`;
        return;
      }
      const {name}  = weather;
      const { temp } = weather.main;
      const description = weather.weather[0].description;
      display.innerHTML = `
        <h3>Weather in ${name}</h3>
        <p><b>Temperature:</b> ${temp} °C</p>
        <p><b>Condition:</b> ${description}</p>
        `;
}
    function handleSearch() {
      const city = document.getElementById("cityInput").value.trim();
      if (city){
        updateInfo(city);
      } else {
        alert("Please enter a city name.");
      }
}